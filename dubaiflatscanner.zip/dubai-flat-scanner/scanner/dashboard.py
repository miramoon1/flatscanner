from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .config import Criteria
from .filters import is_preferred_area
from .models import Listing

PAGE_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dubai Flat Scanner</title>
<style>
  :root {{
    --bg: #f7f5f2; --card: #ffffff; --text: #1a1a1a; --muted: #6b6b6b;
    --accent: #0f6f5c; --border: #e6e2db; --badge: #eaf5f1;
  }}
  @media (prefers-color-scheme: dark) {{
    :root {{ --bg:#15181a; --card:#1f2326; --text:#f1efe9; --muted:#9aa1a6; --accent:#4fd1b5; --border:#2c3134; --badge:#1c2b28; }}
  }}
  * {{ box-sizing: border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--text); font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }}
  header {{ padding: 28px 24px 16px; max-width: 1100px; margin: 0 auto; }}
  h1 {{ margin: 0 0 4px; font-size: 1.5rem; }}
  .meta {{ color: var(--muted); font-size: 0.9rem; }}
  .criteria {{ color: var(--muted); font-size: 0.85rem; margin-top: 8px; }}
  main {{ max-width: 1100px; margin: 0 auto; padding: 8px 24px 48px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }}
  .card {{ background: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; }}
  .card img {{ width: 100%; height: 160px; object-fit: cover; background: var(--border); }}
  .card-body {{ padding: 14px 16px 16px; display: flex; flex-direction: column; gap: 6px; flex: 1; }}
  .price {{ font-size: 1.15rem; font-weight: 700; color: var(--accent); }}
  .title {{ font-weight: 600; font-size: 0.95rem; line-height: 1.3; }}
  .area {{ color: var(--muted); font-size: 0.85rem; }}
  .row {{ display: flex; justify-content: space-between; align-items: center; margin-top: auto; padding-top: 8px; }}
  .badges {{ display:flex; gap:6px; flex-wrap: wrap; }}
  .badge {{ font-size: 0.72rem; background: var(--badge); color: var(--accent); padding: 2px 8px; border-radius: 999px; font-weight: 600; }}
  .source {{ font-size: 0.72rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.04em; }}
  a.card {{ text-decoration: none; color: inherit; }}
  a.card:hover {{ border-color: var(--accent); }}
  .empty {{ color: var(--muted); padding: 40px 0; text-align: center; }}
</style>
</head>
<body>
<header>
  <h1>Dubai Flat Scanner</h1>
  <div class="meta">Last updated {generated_at} &middot; {count} matching listings</div>
  <div class="criteria">Budget &le; {max_price} AED/month &middot; {bedrooms} bed / {bathrooms} bath &middot; excluding Marina &amp; JLT &middot; Jumeirah &amp; water-adjacent areas preferred</div>
</header>
<main>
  <div class="grid">
    {cards}
  </div>
  {empty_state}
</main>
</body>
</html>
"""

CARD_TEMPLATE = """
<a class="card" href="{url}" target="_blank" rel="noopener">
  <img src="{image_url}" alt="" loading="lazy" onerror="this.style.display='none'" />
  <div class="card-body">
    <div class="price">{price} AED/mo</div>
    <div class="title">{title}</div>
    <div class="area">{area}</div>
    <div class="row">
      <div class="badges">
        {preferred_badge}
      </div>
      <div class="source">{source}</div>
    </div>
  </div>
</a>
"""


def _fmt_price(v: float | None) -> str:
    if v is None:
        return "?"
    return f"{v:,.0f}"


def render_dashboard(listings: list[Listing], criteria: Criteria, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    data = [l.to_dict() for l in listings]
    (out_dir / "data.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    cards_html = []
    for l in listings:
        preferred = is_preferred_area(l, criteria)
        cards_html.append(
            CARD_TEMPLATE.format(
                url=l.url,
                image_url=l.image_url or "",
                price=_fmt_price(l.price_monthly_aed),
                title=l.title,
                area=l.area,
                preferred_badge='<span class="badge">Preferred area</span>' if preferred else "",
                source=l.source,
            )
        )

    page = PAGE_TEMPLATE.format(
        generated_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        count=len(listings),
        max_price=f"{criteria.max_price_monthly_aed:,}",
        bedrooms=criteria.bedrooms,
        bathrooms=criteria.bathrooms,
        cards="\n".join(cards_html),
        empty_state='<div class="empty">No matching listings right now — check back later.</div>' if not listings else "",
    )
    (out_dir / "index.html").write_text(page, encoding="utf-8")
